<?php 

return [
	'module_path' => 'module/Poll',
    'layout_path' => 'layout/poll'
];
