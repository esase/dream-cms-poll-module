DROP TABLE IF EXISTS `poll_answer_track`;
DROP TABLE IF EXISTS `poll_answer`;
DROP TABLE IF EXISTS `poll_question`;