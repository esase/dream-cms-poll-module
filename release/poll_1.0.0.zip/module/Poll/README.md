# Poll
Poll module for Dream CMS. Module allows to publish polls on the site.